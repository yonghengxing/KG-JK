@extends('template') @section('content')
<div class="ant-layout-content" style="margin: 10px 24px 0px; height: 100%;">

<iframe name="myframe" src="http://www.baidu.com" style="width:970px;height:800px;"></iframe>



</div>
@stop